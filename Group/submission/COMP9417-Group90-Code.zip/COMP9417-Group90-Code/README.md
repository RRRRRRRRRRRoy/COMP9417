# Otto Group Product Classification Challenge

You can find the official site for this challenge [here](https://www.kaggle.com/c/otto-group-product-classification-challenge/overview) on Kaggle, and download dataset if you want to run our programs.

## How to use
**The dataset is not provided here, you should download the dataset before use. And make sure the data files, ```training.csv``` is stored in the directory or you may place them anywhere but make sure change the path in our files.  We are not responsible if you have 'FileNotFoundError'**

### Environment

You can construct the environment used by running

```shell
pip3 install -r requirements.txt
```

or if your system environment is not relatively old, for example, you use __Python3.8+__, it should be work.

### About the files

File ```utilitiies.py```  contains the function to load data:

```python
def load_data(dataset_name:str='train', onehot:bool=False, shuffle:bool=True, seed:int=10)

  """

  \* dataset_name: 'train'(default, 61876 rows), 'test', or 'sampleSubmisstion';

  \* return features(93 features), labels(9 classes), ids, names of each coloums.

  """
```

And the function to compute log loss, another way to use log loss is use __sklearn.metrics.log_loss__.

Except this file, all other ```.py``` files have the corresponding Jupyter notebook ```.ipynb``` with the same name. And you can find the output of our program there directly since almost of the models are time-consuming. 

For files in folder called __z5241868__, the data location is used the absolute location, this is to avoid submitting the data to the GitHub. If you want to use these files, please change the data location to your own.

